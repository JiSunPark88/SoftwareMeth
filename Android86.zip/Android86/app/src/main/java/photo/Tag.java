package photo;

import java.io.Serializable;

/**
 * @author Seong Bin Park
 * Main Tag object class
 */
public class Tag implements Serializable{
	private static final long serialVersionUID = 1L;

	public enum Type{
		PERSON, LOCATION
	};

	public String value;
	public Type type;

	public Tag(String[] tagSplits){
		this.type = Type.values()[Integer.parseInt(tagSplits[0])];
		this.value = tagSplits[1];
	}
	public Tag(Type tag, String value){
		type = tag;
		value = value;
	}

	public String toString(){return type + "; " + value;}

	public boolean search(Type tag, String value){
		if(this.type != tag)
			return false;
		if(!this.value.contains(value))
			return false;
		return true;
	}
	/**
	 * @param tag
	 * @param value
	 * @return
	 * Two equals are to avoid making a whole instance of TAG when trying to search for tags.
	 * instead of making an instance (and having java to garbage-collect it later on) we can
	 * just pass in the parameters.
	 */
	public boolean equals(Type tag, String value){
		return this.type == tag && this.value.equals(value);
	}
	public boolean equals(Object object){
		if(object == null || !(object instanceof Tag))
			return false;
		Tag tag = (Tag)object;
		return tag.type == this.type && tag.value.equals(this.value);
	}
}