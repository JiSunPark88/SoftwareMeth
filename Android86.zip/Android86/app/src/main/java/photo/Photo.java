package photo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;

public class Photo implements Serializable{
	private static final long serialVersionUID = 3063112440307809632L;

	public String name;
	public String path;

	public ArrayList<Tag> tags;
	public int countsTags;

	public Photo(String name, String path){
		this.name = name;
		this.path = path;
		this.tags = new ArrayList<Tag>();
	}

	public void editCaption(String name){

		this.name = name;
	}

	/**
	 * @param tTag
	 * @return true on success
	 */
	public boolean addToTags(Tag tTag){
		for(Tag tag: tags){
			if(tag.equals(tTag))
				return false;
		}
		tags.add(tTag);
		countsTags = tags.size();
		return true;
	}

	public boolean deleteFromTags(Tag.Type tag, String value){
		for(int i=0; i<tags.size(); i++){
			if(tags.get(i).equals(tag,value)){
				tags.remove(i);
				countsTags--;
				return true;
			}
		}
		return false;
	}

	public String getTags(){
		String tags = "";
		for (int i = 0; i < this.countsTags; i++) {
			if (i != 0)
				tags += ", ";
			tags += this.tags.get(i).value;
		}
		return tags;
	}
	public String toString(){
		String value =  name + "; " + path + "; " + countsTags + "\n";
		if(tags != null && tags.size() > 0)
			for(Tag tTag: tags){
				value += tTag.toString();
				value += "\n";
			}
		return value;
	}

	public static Comparator<Photo> compareName() {
		return new Comparator<Photo>(){
			@Override
			public int compare(Photo arg0, Photo arg1){
				return arg0.name.compareTo(arg1.name);
			}
		};
	}

	public boolean equals(Object object){
		if(object == null || !(object instanceof Photo))
			return false;
		Photo p = (Photo) object;
		return p.path.equals(this.path) && p.name.equals(this.name);
	}
}
