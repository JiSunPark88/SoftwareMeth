package photo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class Album implements Serializable, Comparable<Album>{
	private static final long serialVersionUID = -5903254468625127378L;

	public String name;
	public String photoText;
	public int countsPhotos;
	public ArrayList<Photo> photos;

	public Album(ArrayList<Photo> photo){
		photos = photo;
		countsPhotos = photo.size();
	}
	public Album(String name){
		this.name = name;
		this.photoText = "";
		this.countsPhotos = 0;
		photos = new ArrayList<Photo>();
	}

	public void addToPhotos(Photo photo){
		photos.add(photo);
		countsPhotos++;
	}
	public boolean deleteFromPhotos(Photo photo){
		for(int i=0; i<photos.size(); i++){
			if(photos.get(i).equals(photo)){
				photos.remove(i);
				countsPhotos--;
				return true;
			}
		}
		return false;
	}
	public List<Photo> getPhotos(){

		return photos;
	}

	public Photo getPhoto(int pos){
		if(pos < photos.size())
			return photos.get(pos);
		return null;
	}
	public boolean findPhoto(String path){
		for(Photo photo: photos){
			if(path.equals(photo.path))
				return true;
		}
		return false;
	}

	@Override
	public int compareTo(Album object) {

		return this.name.compareTo(object.name);
	}

	public String toString(){
		String value = "";
		if(name != null)
			value += name + "; ";

		value += countsPhotos + "; ";

		return value;
	}

	/* equal if name and num of photos are the same... */
	public boolean equals(Object object){
		if(object == null || !(object instanceof Album))
			return false;
		Album album = (Album)object;
		return album.name.equals(this.name);
	}

}
