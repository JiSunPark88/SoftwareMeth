package io;

import android.content.Context;
import android.util.Log;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import photo.Album;
import usr.Account;
import usr.User;


/*
DataIO
Static IO class: this class is used w/o an instance so include private variables
 */
public class DataIO {

	private DataIO(){};


	/**
	 * @param <R>
	 * @param <T>
	 * Those parameters are what the functions return in order to read from a specific file
	 */

	public interface IODataReader<R, T>{
		public ArrayList<R> readDir(Context c);
		public ArrayList<T> readAlbum(Context c, R r);
	}

	public static class IOUserReader implements IODataReader<User, Album>{
		@Override
		public ArrayList<User> readDir(Context c) {
			File f = new File(c.getFilesDir() + SVList.USERPATH);
			if(!f.exists()){
				System.out.println("IOUserReader - User folder does not exist!");
				return null;
			}
			File[] files = f.listFiles();

			ArrayList<User> users = new ArrayList<User>();

			for(File x: files){
				String id = x.getName();
				users.add(getUser(id));
			}
			return users;
		}

		/*
		 * getUser generates a user account, reads ablum, and opens photo files
		 * returns u
		 */
		private User getUser(String id){
			User u = new User(id);
			return u;
		}

		@Override
		public ArrayList<Album> readAlbum(Context c, User u){
			File f = new File(c.getFilesDir() + u.pathToData);
			if(!f.exists()){
				try {
					if(!f.createNewFile()){
						Log.d("ERROR", "IOUserReader - could not create data file!");
						return null;
					}
				} catch (IOException e) {e.printStackTrace();}
			}
			return inputStream(f);
		}
	}

	/**
	 * @param account
	 * @return true if save successes
	 * IOException
	 */
	public static boolean save(Context context, Account account) {
		if(account == null)
			return false;
		Log.d("LOG_MESSAGE", "Here");
		File f = new File(context.getFilesDir() + SVList.USERPATH);
		if(!f.exists()){
			try {
				f.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
		}
		Log.d("LOG_MESSAGE", "Here");
		File copy = new File(context.getFilesDir() + SVList.TEMP);
		if(!copy.exists()){
			try {
				copy.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
		}

		boolean successWrite = outputStream(f, copy, account);
		/* rename the new successful copy to the real file name, then delete the old file */
		if(successWrite){
			f.delete();
			File newfile = new File(context.getFilesDir() + SVList.USERPATH);
			copy.renameTo(newfile);
			return true;
		}
		return false;
	}

	/**
	 * @param file
	 * @return Album Lists from a file
	 */
	private static ArrayList<Album> inputStream(File file){
		ArrayList<Album> albums = new ArrayList<Album>();
		FileInputStream f_in = null;
		ObjectInputStream data_in = null;
		try {
			if(file.length() != 0){
				f_in = new FileInputStream(file.getAbsolutePath());
				data_in = new ObjectInputStream(f_in);
				try {
					albums = (ArrayList<Album>) data_in.readObject();
				} catch (ClassNotFoundException e1) {e1.printStackTrace();
				} catch (IOException e1) {e1.printStackTrace();
				} finally {
					try {
						f_in.close();
						data_in.close();
					} catch (IOException e1) {e1.printStackTrace();}
				}
			}
		} catch (EOFException e){
		} catch (IOException e) {e.printStackTrace();return null;
		}

		return albums;
	}

	/**
	 * @param file
	 * @param copyFile
	 * @param account
	 * @return true if success
	 */
	private static boolean outputStream(File file, File copyFile, Account account){
		FileOutputStream f_out = null;
		ObjectOutputStream data_out = null;
		boolean successWrite = false;
		try{
			f_out = new FileOutputStream(copyFile.getAbsolutePath());
			data_out = new ObjectOutputStream(f_out);
			data_out.writeObject(account.albums);
			successWrite = true;
		} catch (IOException e) {e.printStackTrace();return false;
		} finally {
			try {
				f_out.close();
				data_out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return successWrite;
	}
}
