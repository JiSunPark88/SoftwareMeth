package io;

import android.content.Context;
import android.util.Log;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import photo.Album;
import usr.Account;
import usr.User;


/*
DataIO
Static IO class: this class is used w/o an instance so include private variables
 */
public class DataIO {

	private DataIO(){};


	/**
	 * @param <R>
	 * @param <T>
	 * Those parameters are what the functions return in order to read from a specific file
	 */

	public interface IODataReader<R, T>{
		public ArrayList<R> readDir(Context c);
		public ArrayList<T> readAlbum(Context c, R r);
	}

	public static class IOUserReader implements IODataReader<User, Album>{
		@Override
		public ArrayList<User> readDir(Context c) {
			File file = new File(c.getFilesDir() + SVList.USERPATH);
			if(!file.exists()){
				System.out.println("IOUserReader - User folder does not exist!");
				return null;
			}
			File[] fileArray = file.listFiles();

			ArrayList<User> users = new ArrayList<User>();

			for(File xFile: fileArray){
				String id = xFile.getName();
				users.add(getUser(id));
			}
			return users;
		}

		/*
		 * getUser generates a user account, reads ablum, and opens photo files
		 * returns user
		 */
		private User getUser(String id){
			User user = new User(id);
			return user;
		}

		@Override
		public ArrayList<Album> readAlbum(Context context, User user){
			File file = new File(context.getFilesDir() + user.pathToData);
			if(!file.exists()){
				try {
					if(!file.createNewFile()){
						Log.d("ERROR", "Cannot creat file (IOUserReader)");
						return null;
					}
				} catch (IOException exception) {
					exception.printStackTrace();}
			}
			return inputStream(file);
		}
	}

	/**
	 * @param account
	 * @return true if save successes
	 * IOException
	 */
	public static boolean save(Context context, Account account) {
		if(account == null)
			return false;
		Log.d("LOG_MESSAGE", "Here");
		File file = new File(context.getFilesDir() + SVList.USERPATH);
		if(!file.exists()){
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
		}
		Log.d("LOG_MESSAGE", "Here");
		File copyFile = new File(context.getFilesDir() + SVList.TEMP);
		if(!copyFile.exists()){
			try {
				copyFile.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
				return false;
			}
		}

		boolean successWrite = outputStream(file, copyFile, account);
		if(successWrite){
			file.delete();
			File newfile = new File(context.getFilesDir() + SVList.USERPATH);
			copyFile.renameTo(newfile);
			return true;
		}
		return false;
	}

	/**
	 * @param file
	 * @return Album Lists from a file
	 */
	private static ArrayList<Album> inputStream(File file){
		ArrayList<Album> albums = new ArrayList<Album>();
		FileInputStream fileInputStream = null;
		ObjectInputStream objectInputStream = null;
		try {
			if(file.length() != 0){
				fileInputStream = new FileInputStream(file.getAbsolutePath());
				objectInputStream = new ObjectInputStream(fileInputStream);
				try {
					albums = (ArrayList<Album>) objectInputStream.readObject();
				} catch (ClassNotFoundException exception1) {
					exception1.printStackTrace();
				} catch (IOException exception1) {
					exception1.printStackTrace();
				} finally {
					try {
						fileInputStream.close();
						objectInputStream.close();
					} catch (IOException exception1) {
						exception1.printStackTrace();
					}
				}
			}
		} catch (EOFException exception){
		} catch (IOException exception) {
			exception.printStackTrace();return null;
		}

		return albums;
	}

	/**
	 * @param file
	 * @param copyFile
	 * @param account
	 * @return true if success
	 */
	private static boolean outputStream(File file, File copyFile, Account account){
		FileOutputStream fileOutputStream = null;
		ObjectOutputStream objectOutputStream = null;
		boolean isSucess = false;
		try{
			fileOutputStream = new FileOutputStream(copyFile.getAbsolutePath());
			objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(account.albums);
			isSucess = true;
		} catch (IOException exception) {
			exception.printStackTrace();
			return false;
		} finally {
			try {
				fileOutputStream.close();
				objectOutputStream.close();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
		}
		return isSucess;
	}
}
