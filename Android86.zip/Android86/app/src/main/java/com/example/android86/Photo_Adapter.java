package com.example.android86;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import photo.Photo;

public class Photo_Adapter extends ArrayAdapter<Photo>{
    Context context;
    public Photo_Adapter(Context context, ArrayList<Photo> photo){
        super(context, R.layout.grid_item_layout, photo);
        this.context = context;
    }

    @Override
    public View getView(int pos, View view, ViewGroup parentViewGroup) {
        LayoutInflater inflateAlbum = LayoutInflater.from(getContext());
        View customView = inflateAlbum.inflate(R.layout.grid_item_layout, parentViewGroup, false);

        String photo_name = getItem(pos).name;
        String photo_path = getItem(pos).path;

        TextView photo_text = (TextView) customView.findViewById(R.id.photo_text);
        ImageView photo_image = (ImageView) customView.findViewById(R.id.photo_image);
        photo_text.setText(photo_name);
        int drawableInt = context.getResources().getIdentifier(photo_path, "drawable", context.getPackageName());
        photo_image.setImageResource(drawableInt);

        return customView;
    }
}