package com.example.android86;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import io.DataIO;
import photo.Album;
import photo.Photo;
import photo.Tag;
import usr.User;

public class GalleryActivity extends AppCompatActivity {
    User user;
    Album existingAlbum;

    int albumI;
    int position;

    final Context context = this;

    GridView photo_grid_view;
    Photo_Adapter photo_adapter;

    private Button displayButton;
    private Button addButton;
    private Button editButton;
    private Button removeButton;
    private Button moveButton;
    private Button tagButton;
    private Button closeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        displayButton = (Button) findViewById(R.id.displayButton);
        addButton = (Button) findViewById(R.id.addButton);
        editButton = (Button) findViewById(R.id.editButton);
        removeButton = (Button) findViewById(R.id.removeButton);
        moveButton = (Button) findViewById(R.id.moveButton);
        tagButton = (Button) findViewById(R.id.tagButton);
        closeButton = (Button) findViewById(R.id.closeButton);

        user = (User)getIntent().getSerializableExtra(this.getString(R.string.User_Info));
        albumI = getIntent().getIntExtra(this.getString(R.string.Album_Index), 0);
        if(albumI >= 0)
            existingAlbum = user.albums.get(albumI);
        else
            existingAlbum = (Album)getIntent().getSerializableExtra(context.getString(R.string.Album_Info));
        position = -1;
        //test
        Toast.makeText(GalleryActivity.this, existingAlbum.name, Toast.LENGTH_SHORT).show();

        photo_adapter = new Photo_Adapter(this, existingAlbum.photos);
        photo_grid_view = (GridView) findViewById(R.id.gridview);
        photo_grid_view.setAdapter(photo_adapter);

        photo_grid_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int pos, long id) {
                position = pos;
                Toast.makeText(GalleryActivity.this, "" + position,
                        Toast.LENGTH_SHORT).show();
            }
        });

        //display
        displayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if(position <= -1) {
                    position = 0;
                }
                Intent intent = new Intent(getApplicationContext(), DisplayActivity.class);
                intent.putExtra(context.getString(R.string.User_Info), user);
                intent.putExtra(context.getString(R.string.Album_Index), albumI);
                intent.putExtra(context.getString(R.string.Album_Info), existingAlbum);
                intent.putExtra(context.getString(R.string.Photo_Index), position);
                startActivity(intent);
            }
        });

        //add
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                LinearLayout linearLayout = new LinearLayout(context);
                linearLayout.setOrientation(LinearLayout.VERTICAL);

                final EditText photo_name = new EditText(context);
                final EditText photo_path = new EditText(context);
                photo_name.setHint("Type name");
                photo_path.setHint("Type path");

                linearLayout.addView(photo_name);
                linearLayout.addView(photo_path);

                AlertDialog alert = new AlertDialog.Builder(context)
                        .setTitle("Alert")
                        .setMessage("Type Photo Information")
                        .setView(linearLayout)
                        .setPositiveButton("Enter", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                String result_name = photo_name.getText().toString();
                                String result_path = photo_path.getText().toString();
                                if (result_name.isEmpty() || result_path.isEmpty())
                                    return;


                                Photo photo = new Photo(result_name, result_path);
                                existingAlbum.addToPhotos(photo);

                                Toast.makeText(GalleryActivity.this, "Info is added", Toast.LENGTH_SHORT).show();
                                saveData();
                                refreshList();
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                Toast.makeText(GalleryActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .show();
            }
        });
        //edit
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if(position <= -1) {
                    Toast.makeText(GalleryActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                    return;
                }
                LinearLayout linearLayout = new LinearLayout(context);
                linearLayout.setOrientation(LinearLayout.VERTICAL);

                final EditText photo_name = new EditText(context);
                photo_name.setHint("Type new name");

                linearLayout.addView(photo_name);

                AlertDialog alert = new AlertDialog.Builder(context)
                        .setTitle("Alert")
                        .setMessage("Enter Photo Information")
                        .setView(linearLayout)
                        .setPositiveButton("Enter", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                String result_name = photo_name.getText().toString();
                                if (result_name.isEmpty())
                                    return;

                                Photo photo = existingAlbum.getPhoto(position);
                                if(photo == null)
                                    return;

                                photo.name = result_name;

                                Toast.makeText(GalleryActivity.this, "Info is edited", Toast.LENGTH_SHORT).show();
                                saveData();
                                refreshList();
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                Toast.makeText(GalleryActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .show();
            }
        });

        //remove
        removeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                //position = photo_grid_view.getCheckedItemPosition();
                if (position > -1) {
                    try {
                        Photo p = existingAlbum.getPhoto(position);
                        if(p != null && existingAlbum.deleteFromPhotos(p))
                            Toast.makeText(GalleryActivity.this, "Deleted", Toast.LENGTH_SHORT).show();

                    } catch (Exception exception) {
                        Toast.makeText(GalleryActivity.this, "Cannot Delete", Toast.LENGTH_SHORT).show();return;}
                } else {
                    Toast.makeText(GalleryActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                    return;
                }
                position = -1;
                saveData();
                refreshList();
            }
        });

        //move
        moveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if(position <= -1) {
                    Toast.makeText(GalleryActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                    return;
                }

                LinearLayout linearLayout = new LinearLayout(context);
                linearLayout.setOrientation(LinearLayout.VERTICAL);

                final EditText album_name = new EditText(context);
                album_name.setHint("Album Name");

                linearLayout.addView(album_name);

                AlertDialog alertDialog = new AlertDialog.Builder(context)
                        .setTitle("Alert")
                        .setMessage("Type Name of Album")
                        .setView(linearLayout)
                        .setPositiveButton("Enter", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                Photo p = existingAlbum.getPhoto(position);
                                if (p == null)
                                    return;

                                String result_name = album_name.getText().toString();

                                if (result_name.isEmpty())
                                    return;

                                Album albumMoveTo = user.getAlbum(result_name);
                                if (albumMoveTo == null) {
                                    Toast.makeText(GalleryActivity.this, "Album not Exists", Toast.LENGTH_SHORT).show();
                                    return;
                                } else if (albumMoveTo.findPhoto(p.path)){
                                    Toast.makeText(GalleryActivity.this, "Photo already exists", Toast.LENGTH_SHORT).show();
                                    return;
                                }

                                albumMoveTo.addToPhotos(p);
                                existingAlbum.deleteFromPhotos(p);

                                Toast.makeText(GalleryActivity.this, "Moved", Toast.LENGTH_SHORT).show();
                                saveData();
                                refreshList();
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                Toast.makeText(GalleryActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .show();
            }
        });

        // REALLY FOR THE DISPLAY ACTIVITY
        tagButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(position <= -1) {
                    Toast.makeText(GalleryActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                    return;
                }

                LinearLayout linearLayout = new LinearLayout(context);
                linearLayout.setOrientation(LinearLayout.VERTICAL);

                final Spinner tag_type = new Spinner(context);
                tag_type.setAdapter(new ArrayAdapter<Tag.Type>(context, android.R.layout.simple_spinner_item, Tag.Type.values()));
                final EditText tag_value = new EditText(context);
                tag_value.setHint("Tag Value");

                linearLayout.addView(tag_type);
                linearLayout.addView(tag_value);

                AlertDialog alertDialog = new AlertDialog.Builder(context)
                        .setTitle("Alert")
                        .setMessage("Type Tag Information")
                        .setView(linearLayout)
                        .setPositiveButton("Enter", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                Photo photo = existingAlbum.getPhoto(position);
                                if (photo == null)
                                    return;

                                Tag.Type result_type = (Tag.Type)tag_type.getSelectedItem();
                                String result_value = tag_value.getText().toString();

                                if (result_value.isEmpty() || result_type == null)
                                    return;

                                Tag tag = new Tag(result_type, result_value);
                                photo.addToTags(tag);

                                Toast.makeText(GalleryActivity.this, "Tag is added", Toast.LENGTH_SHORT).show();
                                saveData();
                                refreshList();
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                Toast.makeText(GalleryActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .show();
            }
        });
        //close
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean checkPhotoPathExists(ArrayList<Photo> photoList, String path){
        for(Photo photo: photoList){
            if(photo.path.equals(path)){
                return true;
            }
        }
        return false;
    }

    private boolean checkPhotoNameExists(ArrayList<Photo> photoList, String name){
        for(Photo photo: photoList){
            if(photo.name.equalsIgnoreCase(name)){
                return true;
            }
        }
        return false;
    }

    public void saveData(){
        if(DataIO.save(context, user))
            Toast.makeText(GalleryActivity.this, "Saved", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(GalleryActivity.this, "FAILED TO SAVE", Toast.LENGTH_LONG).show();
    }
    public void refreshList(){
        photo_adapter.notifyDataSetChanged();
        photo_grid_view.setAdapter(photo_adapter);
    }
}

