package com.example.android86;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class ImageAdapter extends BaseAdapter{
    private Context mContext;

    public ImageAdapter(Context context) {

        mContext = context;
    }

    public int getCount() {

        return mThumbIds.length;
    }

    public Object getItem(int pos) {

        return null;
    }

    public long getItemId(int pos) {

        return 0;
    }

    /*
    This method is to create a new imageView
    If a new imageView is not recycles, initilize
     */
    public View getView(int pos, View convertView, ViewGroup parent) {
        ImageView imageView;
        if (convertView == null) {
            imageView = new ImageView(mContext);
            imageView.setLayoutParams(new GridView.LayoutParams(85, 85));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8, 8, 8, 8);
        } else {
            imageView = (ImageView) convertView;
        }

        imageView.setImageResource(mThumbIds[pos]);
        return imageView;
    }

    private Integer[] mThumbIds = {
            R.drawable.sample3, R.drawable.sample4,
            R.drawable.sample5, R.drawable.sample6,
            R.drawable.sample7, R.drawable.sample8,
            R.drawable.sample1, R.drawable.sample2,
            R.drawable.sample3, R.drawable.sample4,
            R.drawable.sample5, R.drawable.sample6,
            R.drawable.sample7, R.drawable.sample8,
            R.drawable.sample1, R.drawable.sample2,
            R.drawable.sample3, R.drawable.sample4,
            R.drawable.sample5, R.drawable.sample6,
            R.drawable.sample7, R.drawable.sample8
    };
}
