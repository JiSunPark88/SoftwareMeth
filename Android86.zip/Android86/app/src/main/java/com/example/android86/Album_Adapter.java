package com.example.android86;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import photo.Album;

public class Album_Adapter extends ArrayAdapter<Album> {
    public Album_Adapter(Context context,  ArrayList<Album> album) {
        super(context, R.layout.album_list, album);
    }

    @Override
    public View getView(int pos, View view, ViewGroup parent) {
        LayoutInflater albumInflater = LayoutInflater.from(getContext());
        View customView = albumInflater.inflate(R.layout.album_list, parent, false);

        String album_name = getItem(pos).name;
        TextView album_text = (TextView) customView.findViewById(R.id.album_text);

        album_text.setText(album_name);

        return customView;
    }
}
