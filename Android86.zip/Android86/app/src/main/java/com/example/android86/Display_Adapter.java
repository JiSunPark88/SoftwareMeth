package com.example.android86;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import photo.Tag;

public class Display_Adapter extends ArrayAdapter<Tag> {
    public Display_Adapter(Context context, ArrayList<Tag> tags){
        super(context,R.layout.tag_list, tags);
    }

    @Override
    public View getView(int pos, View convertView, ViewGroup parentViewGroup) {
        LayoutInflater albumInflater = LayoutInflater.from(getContext());
        View customView = albumInflater.inflate(R.layout.tag_list, parentViewGroup, false);

        Tag.Type tagType = getItem(pos).type;
        String tagTypeString = tagType.name();
        String tagValue = getItem(pos).value;

        TextView type_text_view = (TextView) customView.findViewById(R.id.tag_type_view);
        TextView value_text_view = (TextView) customView.findViewById(R.id.tag_type_value);

        type_text_view.setText(tagTypeString);
        value_text_view.setText(tagValue);

        return customView;
    }
}
