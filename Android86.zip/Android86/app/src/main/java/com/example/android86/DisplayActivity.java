package com.example.android86;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import io.DataIO;
import photo.Album;
import photo.Photo;
import photo.Tag;
import usr.User;

public class DisplayActivity extends AppCompatActivity {
    User user;
    int albumI;
    int photoI;
    Album existingAlbum;
    Photo existingPhoto;

    final Context context = this;

    ListView tag_list_view;
    Display_Adapter display_adapter;
    ArrayList<Tag> existingTags;

    private Button addtagButton;
    private Button removetagButton;
    private Button leftButton;
    private Button rightButton;
    private Button closeButton;

    ImageView image_display;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        addtagButton = (Button) findViewById(R.id.addTag);
        removetagButton = (Button) findViewById(R.id.removeTag);
        leftButton = (Button) findViewById(R.id.leftPhoto);
        rightButton = (Button) findViewById(R.id.rightPhoto);
        closeButton = (Button) findViewById(R.id.close);

        user = (User)getIntent().getSerializableExtra(this.getString(R.string.User_Info));
        albumI = getIntent().getIntExtra(this.getString(R.string.Album_Index), 0);
        photoI = getIntent().getIntExtra(this.getString(R.string.Photo_Index), 0);
        if(albumI >= 0)
            existingAlbum = user.getAlbum(albumI);
        else
            existingAlbum = (Album)getIntent().getSerializableExtra(this.getString(R.string.Album_Info));
        existingPhoto = existingAlbum.getPhoto(photoI);

        Toast.makeText(DisplayActivity.this, existingPhoto.name, Toast.LENGTH_SHORT).show();

        existingTags = new ArrayList<Tag>();
        existingTags.addAll(existingPhoto.tags);
        display_adapter = new Display_Adapter(this, existingTags);
        tag_list_view = (ListView) findViewById(R.id.tagView);
        tag_list_view.setAdapter(display_adapter);

        image_display = (ImageView)findViewById(R.id.image_display);
        int draw = context.getResources().getIdentifier(existingPhoto.path, "drawable", context.getPackageName());
        image_display.setImageResource(draw);

        addtagButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                LinearLayout linearLayout = new LinearLayout(context);
                linearLayout.setOrientation(LinearLayout.VERTICAL);

                final Spinner tag_type = new Spinner(context);
                tag_type.setAdapter(new ArrayAdapter<Tag.Type>(context, android.R.layout.simple_spinner_item, Tag.Type.values()));
                final EditText tag_value = new EditText(context);
                tag_value.setHint("Tag Value");

                linearLayout.addView(tag_type);
                linearLayout.addView(tag_value);

                AlertDialog alert = new AlertDialog.Builder(context)
                        .setTitle("Alert")
                        .setMessage("Enter Tag")
                        .setView(linearLayout)
                        .setPositiveButton("Enter", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                Tag.Type result_type = (Tag.Type)tag_type.getSelectedItem();
                                String result_value = tag_value.getText().toString();

                                if (result_value.isEmpty() || result_type == null)
                                    return;

                                Tag tag = new Tag(result_type, result_value);
                                existingPhoto.addToTags(tag);

                                Toast.makeText(DisplayActivity.this, "Tag is added", Toast.LENGTH_SHORT).show();
                                saveData();
                                refreshList();
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                Toast.makeText(DisplayActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .show();
            }
        });

        removetagButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                LinearLayout linearLayout = new LinearLayout(context);
                linearLayout.setOrientation(LinearLayout.VERTICAL);

                final Spinner tag_type = new Spinner(context);
                tag_type.setAdapter(new ArrayAdapter<Tag.Type>(context, android.R.layout.simple_spinner_item, Tag.Type.values()));
                final EditText tag_value = new EditText(context);
                tag_value.setHint("Tag Value");

                linearLayout.addView(tag_type);
                linearLayout.addView(tag_value);

                AlertDialog alert = new AlertDialog.Builder(context)
                        .setTitle("Alert")
                        .setMessage("Delete Tag")
                        .setView(linearLayout)
                        .setPositiveButton("Enter", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                Tag.Type result_type = (Tag.Type)tag_type.getSelectedItem();
                                String result_value = tag_value.getText().toString();

                                if (result_value.isEmpty() || result_type == null)
                                    return;

                                if(!existingPhoto.deleteFromTags(result_type, result_value)){
                                    Toast.makeText(DisplayActivity.this, "Tag not Exists", Toast.LENGTH_SHORT).show();
                                    return;
                                }

                                Toast.makeText(DisplayActivity.this, "Tag is deleted", Toast.LENGTH_SHORT).show();
                                saveData();
                                refreshList();
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                Toast.makeText(DisplayActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .show();
            }
        });

        leftButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                photoI = --photoI<0? existingAlbum.photos.size()-1:photoI;
                refreshPhoto(photoI);
            }
        });

        rightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                photoI = ++photoI>=existingAlbum.photos.size()? 0:photoI;
                refreshPhoto(photoI);
            }
        });

        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                try{
                    Intent intent = new Intent(getApplicationContext(), GalleryActivity.class);
                    intent.putExtra(context.getString(R.string.User_Info), user);
                    intent.putExtra(context.getString(R.string.Album_Index), albumI);
                    intent.putExtra(context.getString(R.string.Album_Info), existingAlbum);
                    startActivity(intent);
                } catch (Exception exception) {
                    Toast.makeText(DisplayActivity.this, "Cannot Open", Toast.LENGTH_SHORT).show();}
            }
        });

    }

    public void saveData(){
        if(DataIO.save(context, user))
            Toast.makeText(DisplayActivity.this, "Saved", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(DisplayActivity.this, "FAILED TO SAVE", Toast.LENGTH_LONG).show();
    }
    public void refreshList(){
        existingTags.clear();
        existingTags.addAll(existingPhoto.tags);
        display_adapter.notifyDataSetChanged();
        tag_list_view.setAdapter(display_adapter);
    }

    public void refreshPhoto(int pos){
        existingPhoto = existingAlbum.getPhoto(pos);
        image_display = (ImageView)findViewById(R.id.image_display);
        int draw = context.getResources().getIdentifier(existingPhoto.path, "drawable", context.getPackageName());
        image_display.setImageResource(draw);

        existingTags.clear();
        existingTags.addAll(existingPhoto.tags);
        display_adapter.notifyDataSetChanged();
    }
}
