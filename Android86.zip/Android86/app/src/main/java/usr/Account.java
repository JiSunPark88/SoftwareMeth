package usr;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

import photo.Album;
import photo.Photo;
import photo.Tag;

public class Account implements Serializable {
	public String name;
	public ArrayList<Album> albums;
	public String pathToData;

	public Account(String name){
		this.name = name;
		albums = new ArrayList<Album>();
	}

	public String getName(){
		return name;}

	public Album getAlbum(int pos){
		if(pos < albums.size())
			return albums.get(pos);
		return null;
	}

	public Album getAlbum(String name){
		for(Album album: albums){
			if(album.name.equals(name))
				return album;
		}
		return null;
	}

	public boolean addAlbum(Album album){
		if(album_exists(album) || !albums.add(album))
			return false;

		Collections.sort(albums);
		return true;
	}
	public boolean removeAlbum(Album album){
		if(albums.size() < 1)
			return false;
		return albums.remove(album);
	}

	public ArrayList<Photo> searchByTagPair(Tag.Type type, String value){
		if(albums.isEmpty())
			return null;

		ArrayList<Photo> searchPhoto = new ArrayList<Photo>();
		for(Album album: albums){
			for(Photo photo: album.photos){
				for(Tag tag: photo.tags){
					if(tag.search(type,value)){
						searchPhoto.add(photo);
						break;
					}
				}
			}
		}

		return searchPhoto;
	}

	public boolean album_exists(Album a){
		for(Album album: albums){
			if(album.equals(a))
				return true;
		}
		return false;
	}
	public boolean album_exists(String name){
		for(Album album: albums){
			if(album.name.equals(name))
				return true;
		}
		return false;
	}
}
