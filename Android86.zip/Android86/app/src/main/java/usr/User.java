package usr;

import android.content.Context;

import io.DataIO;
import io.SVList;
import photo.Album;
import photo.Photo;


public class User extends Account{
	public User(String name){
		super(name);
		pathToData = SVList.USERPATH;
	}

	public boolean setAlbums(Context context, DataIO.IODataReader reader){
		this.albums = reader.readAlbum(context, this);
		if(albums == null)
			return false;
		return true;
	}

	public String toString(){
		String value = name + "\n";
		for(Album album: albums){
			value += album + "\n";
			for(Photo photo: album.photos){
				value += photo + "\n";
			}
		}

		return value;
	}
}
